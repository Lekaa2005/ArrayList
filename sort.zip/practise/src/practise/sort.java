package practise;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
public class sort {
	public static void main(String[] args) {
	ArrayList<Integer> num=new ArrayList<Integer>();
	num.add(22);
	num.add(42);
	num.add(89);
	num.add(42);
	num.add(78);
	num.add(99);
	Collections.sort(num);     //ascending order
	System.out.println(num);
	Collections.sort(num,Collections.reverseOrder());  //descending order
	for(int n : num) {
		System.out.println(n);
	}

	Scanner sc=new Scanner(System.in);
	ArrayList<String> name=new ArrayList<String>();
	System.out.println("Enter how many words");
	int m = Integer.parseInt(sc.nextLine()); // Convert string to int
	System.out.println("Enter " + m + " words");
	for(int i=0;i<m;i++) {
		name.add(sc.nextLine());  
	}
	Collections.sort(name);
	System.out.println("Sorted order :");
	for (String nat:name) {
		System.out.println(nat);
	}
	
	Scanner scan=new Scanner(System.in);
	ArrayList<Integer> number=new ArrayList<Integer>();
	System.out.println("Enter how many numbers");
	int l = (scan.nextInt()); 
	System.out.println("Enter " + l + " numbers");
	for(int i=0;i<l;i++) {
		number.add(scan.nextInt());  
	}
	Collections.sort(number);
	System.out.println("Sorted order :");
	for (int mat:number) {
		System.out.println(mat);
	}
	sc.close();
	} 
}
